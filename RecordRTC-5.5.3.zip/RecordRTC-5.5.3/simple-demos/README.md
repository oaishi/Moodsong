| DemoTitle        | TestLive           | ViewSource |
| ------------- |-------------|-------------|
| 16khz-audio-recording.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/16khz-audio-recording.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/16khz-audio-recording.html) |
| Record-Mp3-or-Wav.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/Record-Mp3-or-Wav.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/Record-Mp3-or-Wav.html) |
| RecordRTCPromisesHandler.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/RecordRTCPromisesHandler.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/RecordRTCPromisesHandler.html) |
| audio-recording.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/audio-recording.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/audio-recording.html) |
| auto-stop-on-silence.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/auto-stop-on-silence.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/auto-stop-on-silence.html) |
| bitsPerSecond.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/bitsPerSecond.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/bitsPerSecond.html) |
| calculate-recording-duration.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/calculate-recording-duration.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/calculate-recording-duration.html) |
| destroy.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/destroy.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/destroy.html) |
| edge-audio-recording.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/edge-audio-recording.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/edge-audio-recording.html) |
| gif-recording.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/gif-recording.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/gif-recording.html) |
| multi-audios-recording.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/multi-audios-recording.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/multi-audios-recording.html) |
| multi-cameras-recording.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/multi-cameras-recording.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/multi-cameras-recording.html) |
| onStateChanged.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/onStateChanged.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/onStateChanged.html) |
| onTimeStamp.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/onTimeStamp.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/onTimeStamp.html) |
| ondataavailable-StereoAudioRecorder.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/ondataavailable-StereoAudioRecorder.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/ondataavailable-StereoAudioRecorder.html) |
| ondataavailable.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/ondataavailable.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/ondataavailable.html) |
| pass-getUserMedia-constraints.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/pass-getUserMedia-constraints.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/pass-getUserMedia-constraints.html) |
| php-upload-jquery.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/php-upload-jquery.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/php-upload-jquery.html) |
| php-upload-simple-javascript.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/php-upload-simple-javascript.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/php-upload-simple-javascript.html) |
| preview-blob-size-during-recording.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/preview-blob-size-during-recording.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/preview-blob-size-during-recording.html) |
| raw-pcm.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/raw-pcm.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/raw-pcm.html) |
| record-cropped-screen.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/record-cropped-screen.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/record-cropped-screen.html) |
| recording-html-element.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/recording-html-element.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/recording-html-element.html) |
| reuse-same-instance.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/reuse-same-instance.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/reuse-same-instance.html) |
| setRecordingDuration.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/setRecordingDuration.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/setRecordingDuration.html) |
| show-animated-bar-on-video.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/show-animated-bar-on-video.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/show-animated-bar-on-video.html) |
| show-logo-on-recorded-video.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/show-logo-on-recorded-video.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/show-logo-on-recorded-video.html) |
| video-mirror-recording.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/video-mirror-recording.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/video-mirror-recording.html) |
| video-plus-screen-recording.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/video-plus-screen-recording.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/video-plus-screen-recording.html) |
| video-recording.html | [Demo](https://www.webrtc-experiment.com/RecordRTC/simple-demos/video-recording.html) | [Source](https://github.com/muaz-khan/RecordRTC/blob/master/simple-demos/video-recording.html) |

## License

[RecordRTC.js](https://github.com/muaz-khan/RecordRTC) is released under [MIT licence](https://www.webrtc-experiment.com/licence/) . Copyright (c) [Muaz Khan](http://www.MuazKhan.com).
